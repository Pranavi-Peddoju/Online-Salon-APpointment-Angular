import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { SalonserviceModule } from './salonservice/salonservice.module';

import { PaymentModule } from './payment/payment.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomerModule } from './customer/customer.module';
import { LoginComponent } from './login/login.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppointmentModule } from './appointment/appointment.module';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ForgotPasswordComponent } from './login/forgot-password/forgot-password.component';
import { ChangePasswordComponent } from './login/change-password/change-password.component';
import { AgmCoreModule } from '@agm/core';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { OrderModule } from './order/order.module';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    HomeComponent,
    LoginComponent,
    PageNotFoundComponent,
    ForgotPasswordComponent,
    ChangePasswordComponent,
    ContactUsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SalonserviceModule,
    HttpClientModule,
    CustomerModule,
    ReactiveFormsModule,
    NgbModule,
    FormsModule,
    CustomerModule,
    AppointmentModule,
    OrderModule,
    PaymentModule,
    AgmCoreModule.forRoot({
      apiKey:'AIzaSyAr05wufqcI39lHkBf-d2vcTRzBMLtZ7kA'
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
