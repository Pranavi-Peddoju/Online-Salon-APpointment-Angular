import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/login/User';
import { UserCredentials } from 'src/app/login/UserCredentials';
import { Customer } from '../../Customer';
import { CustomerApiService } from '../../customer-api.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})
export class AddressComponent implements OnInit {

  isLoggedIn = false;
  role = '';
  showAlert:boolean
  user:User;
  userCredential:UserCredentials
  submitted = false;
customer:Customer
  constructor(private builder:FormBuilder,private route:Router, private service:CustomerApiService) { 
    this.service.getById(Number(localStorage.getItem("userId"))).subscribe(
      res=>{
        this.customer=res
        console.log(this.customer)
      }
    )
  }

  ngOnInit(): void {
  }

  updateForm = this.builder.group(
    {
      userId:[Number(localStorage.getItem("userId"))],
      userName:['',Validators.required],
      password:['',[Validators.required, Validators.minLength(6)]],
      name:['',Validators.required],
      email:['',Validators.required],
      contactNo:['',[Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern("[0-9]+")]],
      dob:['',Validators.required],
      address:this.builder.group({
        doorNo:['',Validators.required],
        street:['',[Validators.required, Validators.minLength(6)]],
        city:['',Validators.required],
       state:['',Validators.required],
        pinCode:['',[Validators.required,Validators.minLength(6),Validators.maxLength(6), Validators.pattern("[0-9]+")]]
      })
  })

  get f() { return this.updateForm.controls; }

  updateUser() {

    console.log(this.updateForm.value)
    this.service.update(this.updateForm.value).subscribe(
      res=>{
        this.route.navigate(['/customer'])
        alert("Updated Successfully")
      },
      err=>{
        alert("Update Failed retry again")
      }
    )

   }
}
