import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerComponent } from './customer/customer.component';
import { AdminComponent } from './admin/admin.component';
import { AdminDetailsComponent } from './admin/admin-details/admin-details.component';
import { RegisterComponent } from './customer/register/register.component';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConfirmRegisterComponent } from './customer/confirm-register/confirm-register.component';
import { AddressComponent } from './customer/address/address.component';



@NgModule({
  declarations: [CustomerComponent, AdminComponent, AdminDetailsComponent, RegisterComponent, ConfirmRegisterComponent, AddressComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class CustomerModule { }
