import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAppointmentComponent } from './appointment/admin-appointment/admin-appointment.component';
import { AppointmentServiceComponent } from './appointment/appointment-service/appointment-service.component';
import { CustomerAppointmentComponent } from './appointment/customer-appointment/customer-appointment.component';
import { UpdateappointmentComponent } from './appointment/updateappointment/updateappointment.component';
import { AuthGuard } from './auth.guard';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { Address } from './customer/Address';
import { AdminDetailsComponent } from './customer/admin/admin-details/admin-details.component';
import { AdminComponent } from './customer/admin/admin.component';
import { AddressComponent } from './customer/customer/address/address.component';
import { ConfirmRegisterComponent } from './customer/customer/confirm-register/confirm-register.component';
import { CustomerComponent } from './customer/customer/customer.component';
import { RegisterComponent } from './customer/customer/register/register.component';
import { HomeComponent } from './home/home.component';
import { ChangePasswordComponent } from './login/change-password/change-password.component';
import { ForgotPasswordComponent } from './login/forgot-password/forgot-password.component';
import { LoginComponent } from './login/login.component';
import { AddordersComponent } from './order/add-order/addorders.component';
import { AdminOrdersComponent } from './order/admin-orders/admin-orders.component';
import { CustomerordersComponent } from './order/customerorders/customerorders.component';
import { OrdersComponent } from './order/orders/orders.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AddPaymentComponent } from './payment/add-payment/add-payment.component';
import { AdminPaymentComponent } from './payment/admin-payment/admin-payment.component';
import { ConfirmPaymentComponent } from './payment/confirm-payment/confirm-payment.component';
import { PaymentService } from './payment/payment.service';
import { AddServiceComponent } from './salonservice/add-service/add-service.component';
import { AdminServicesViewComponent } from './salonservice/admin-services-view/admin-services-view.component';
import { SalonServiceComponent } from './salonservice/salon-service/salon-service.component';
import { ServicesAdminDashboardComponent } from './salonservice/services-admin-dashboard/services-admin-dashboard.component';
import { ShowBypriceComponent } from './salonservice/show-byprice/show-byprice.component';
import { UpdateServiceComponent } from './salonservice/update-service/update-service.component';

const routes: Routes = [

  //service-routes
  {
    path:'salon-services', component:SalonServiceComponent,
  },
  {
    path:'salon-service/:id', component: SalonServiceComponent
  },
  {
    path:'salon-service/name/:name',component:SalonServiceComponent
  },
  {
    path:'pricerange' , component:ShowBypriceComponent
  },
  {
    path:'services-dashboard', component:ServicesAdminDashboardComponent, canActivate: [AuthGuard]
  },
  {
    path:'update-service/:id',component:UpdateServiceComponent, canActivate: [AuthGuard]
  },
  {
    path:'addservice',component:AddServiceComponent, canActivate: [AuthGuard]
  },

  //user-routes
  {
    path:'forgot-password', component:ForgotPasswordComponent
  },
  {
    path:'change-password', component:ChangePasswordComponent, canActivate:[AuthGuard]
  },
  { 
    path: 'login', component: LoginComponent 
  },

  //customer-routes
  { 
    path: 'register', component: RegisterComponent 
  },
  { 
    path: 'customer', component: CustomerComponent, canActivate: [AuthGuard] 
  },
  {
    path:'address' , component:AddressComponent
  },

  //admin-routes
  { 
    path: 'admin', component: AdminComponent, canActivate: [AuthGuard] 
  },
  {
    path:'admin-details-dashboard', component:AdminDetailsComponent,canActivate: [AuthGuard] 
  },
  {
    path:'admin-view-services', component:AdminServicesViewComponent, canActivate: [AuthGuard]
  },
 
//Order Routes
{
  path:'customer-order/:userId',component:CustomerordersComponent, canActivate: [AuthGuard]
},
{
  path:'delete-order/:orderId',component:CustomerordersComponent, canActivate: [AuthGuard]
},
 {
   path:'place-order/:id', component:OrdersComponent, canActivate: [AuthGuard]
},
{
  path:'add-service-order',component:SalonServiceComponent, canActivate: [AuthGuard]
},
{
  path:'orders',component:AdminOrdersComponent, canActivate: [AuthGuard]
},
{
  path:'get-order/:id',component:CustomerordersComponent, canActivate: [AuthGuard]
},
{
  path:'admin-orders',component:AdminOrdersComponent, canActivate: [AuthGuard]
},
{
  path:'add-order',component:AddordersComponent, canActivate: [AuthGuard]
},

//appointment route
{
path:'book-appointment/:id',component:AppointmentServiceComponent, canActivate: [AuthGuard]
},
{
path:'customer-appointment/:id',component:CustomerAppointmentComponent, canActivate: [AuthGuard]
},
{
path:'delete-appointment/:appointmentId',component:CustomerAppointmentComponent, canActivate: [AuthGuard]
},
{
path:'get-appointment/:id',component:CustomerAppointmentComponent, canActivate: [AuthGuard]
},
{
path:'add-appointment',component:SalonServiceComponent, canActivate: [AuthGuard]
},
{
path:'update-appointment/:id',component:UpdateappointmentComponent, canActivate: [AuthGuard]
},
{
path:'appointment-dashboard',component:AdminAppointmentComponent, canActivate: [AuthGuard]
},

//payment routes
// {
// path:'payment/:method',component:SalonServiceComponent
// },
{
  path:'admin-view-services', component:AdminServicesViewComponent, canActivate: [AuthGuard]
},
{
  path:'payment/:method', component:AddPaymentComponent, canActivate: [AuthGuard]
},
{
  path:'admin-payment-view', component:AdminPaymentComponent, canActivate: [AuthGuard]
},
{
  path:'payment', component:PaymentService, canActivate: [AuthGuard]
},
{
  path:'confirm-payment', component:ConfirmPaymentComponent, canActivate: [AuthGuard]
},

{
  path:'**', component:HomeComponent
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
