import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SalonService } from '../salon-service';
import { SalonServiceApiService } from '../salon-service-api.service';

@Component({
  selector: 'app-display-by-name',
  templateUrl: './display-by-name.component.html',
  styleUrls: ['./display-by-name.component.css']
})
export class DisplayByNameComponent implements OnInit {

  name:string
  salonservices:Array<SalonService>=[]
  constructor(private param:ActivatedRoute, private serviceApi:SalonServiceApiService) { }

  ngOnInit(): void {
    this.param.params.subscribe(
      (param) => {
        let name = param['name']
        this.serviceApi.getServiceByName(name).subscribe(
          res=>{
            this.salonservices=res
          }
        )
      }
    )
  }

}
