import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayByNameComponent } from './display-by-name.component';

describe('DisplayByNameComponent', () => {
  let component: DisplayByNameComponent;
  let fixture: ComponentFixture<DisplayByNameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplayByNameComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayByNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
