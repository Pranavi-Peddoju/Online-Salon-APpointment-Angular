import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SalonServiceApiService } from '../salon-service-api.service';

@Component({
  selector: 'app-add-service',
  templateUrl: './add-service.component.html',
  styleUrls: ['./add-service.component.css']
})
export class AddServiceComponent implements OnInit {

  constructor(private builder:FormBuilder, private serviceapi:SalonServiceApiService,private route:Router) { }

  ngOnInit(): void {
  }

  serviceForm = this.builder.group({
    serviceName:['', Validators.required],
    discount:['',Validators.required],
    duration:['',Validators.required],
    price:['',Validators.required]
  })

  get f(){
    return this.serviceForm.controls;
  }

  addService(){
    this.serviceapi.addService(this.serviceForm.value).subscribe(
      res=>{
        console.log(this.serviceForm.value)
        this.route.navigate(['/admin-view-services'])
      }
    )
  }  

}
