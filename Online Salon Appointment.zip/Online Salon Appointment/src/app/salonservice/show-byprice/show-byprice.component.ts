import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SalonService } from '../salon-service';
import { SalonServiceApiService } from '../salon-service-api.service';

import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-show-byprice',
  templateUrl: './show-byprice.component.html',
  styleUrls: ['./show-byprice.component.css']
})
export class ShowBypriceComponent implements OnInit {

  price1:string
  price2:string
  salonservices:Array<SalonService>=[]
  constructor(private activatedroute:ActivatedRoute, private serviceapi:SalonServiceApiService) { }

  ngOnInit(): void {
    this.activatedroute.queryParams.subscribe(
      data =>{
        console.log(data)
        this.price1 = data.price1
        this.price2 = data.price2
        //console.log(this.price1, this.price2)
        this.serviceapi.getServiceByPrice(this.price1,this.price2).subscribe(
          res=>{
            this.salonservices =res
            console.log(res)
          },
          err=>{
            alert("Sorry No Services in this price range")
          }
        )
      }
    )
  }

  // open(content) {
  //   this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
  //     this.closeResult = `Closed with: ${result}`;
  //   }, (reason) => {
  //     this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  //   });
  // }

  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return `with: ${reason}`;
  //   }
  // }


}
