import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SalonService } from '../salon-service';
import { SalonServiceApiService } from '../salon-service-api.service';

@Component({
  selector: 'app-show-service',
  templateUrl: './show-service.component.html',
  styleUrls: ['./show-service.component.css']
})
export class ShowServiceComponent implements OnInit {
  id:number
  service:SalonService
  yes:boolean=false
  constructor(private serviceApi:SalonServiceApiService,private param:ActivatedRoute) { }

  ngOnInit(): void {
    this.param.params.subscribe(
      (param) => {
        let id = param['id']
        this.serviceApi.getServiceById(id).subscribe(
          res=>{
            this.service=res
            this.yes=true
          }
        )
      }
    )
  }


}
