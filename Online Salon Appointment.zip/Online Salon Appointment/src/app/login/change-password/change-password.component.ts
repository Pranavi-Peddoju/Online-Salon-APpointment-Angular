import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginApiService } from '../login-api.service';
import { UserDetails } from '../UserDetails';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  submitted: boolean;
  userDetails:UserDetails
  constructor(private builder:FormBuilder, private service:LoginApiService, private route:Router) { }

  ngOnInit(): void {
  }

  changeForm =this.builder.group(
    {
      username:[localStorage.getItem('userId')],
      oldPassword:['',[Validators.required, Validators.minLength(6)]],
      newPassword:['', [Validators.required,Validators.minLength(6)]]
    }
  )

  get f(){
    return this.changeForm.controls;
  }
  
    forgotPassword(){
      this.submitted = true;
        if (this.changeForm.invalid) {
            return;
        }
        console.log(this.changeForm.value)
        this.service.changePassword(this.changeForm.value).subscribe(
          res=>{
            console.log(this.changeForm.value)
            alert("Password Changed")
            this.route.navigate(['/customer'])
          },
          err=>{
            alert("Invalid Old Password")
          }
        )

       
      
    }
}
