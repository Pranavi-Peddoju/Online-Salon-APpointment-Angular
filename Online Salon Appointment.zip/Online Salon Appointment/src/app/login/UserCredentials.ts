export class UserCredentials{
    username:string 
    password:string
}