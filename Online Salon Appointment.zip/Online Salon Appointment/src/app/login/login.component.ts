import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';
import { NavbarService } from '../navbar/navbar.service';
import { LoginApiService } from './login-api.service';
import { User } from './User';
import { UserCredentials } from './UserCredentials';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  isLoggedIn = false;
  role = '';
  showAlert:boolean
  user:User;
  userCredential:UserCredentials
  submitted = false;

  constructor(private builder:FormBuilder,private navbarService: NavbarService,private route:Router, private loginApi:LoginApiService,) { 
    this.navbarService.getLoginStatus().subscribe(status => this.isLoggedIn = status);
  }

  ngOnInit(): void {
  }

  loginForm = this.builder.group(
    {
      username:['',Validators.required],
      password:['',[Validators.required, Validators.minLength(6)]]
  })

  get f() { return this.loginForm.controls; }

  loginUser() {
    this.loginApi.login(this.loginForm.value).subscribe(
      res=>{
        this.user=res
        this.route.navigate(['/salon-services'])
        let id = this.user.userId+""
        localStorage.setItem("userId", id)
        localStorage.setItem("status", "1")
        this.showAlert  = true
        this.navbarService.updateNavAfterAuth()
      },
      err=>{
        alert("Invalid User Name/User Id or password");
        this.showAlert  = true
      }
    )
  }


}
