export class UserDetails{
    username:string
    oldPassword:string
    newPassword:string
}