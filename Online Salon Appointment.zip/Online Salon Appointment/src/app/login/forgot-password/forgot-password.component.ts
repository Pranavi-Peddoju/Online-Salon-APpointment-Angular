import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginApiService } from '../login-api.service';
import { MustMatch } from './match-pass-valdator';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  submitted: boolean;

  constructor(private builder:FormBuilder, private service:LoginApiService,private route:Router) { }

  ngOnInit(): void {
  }

  forgotForm =this.builder.group(
    {
      username:['',Validators.required],
      password:['',[Validators.required, Validators.minLength(6)]],
      reenterPassword:['', [Validators.required,Validators.minLength(6)]]
    }, 
    {validator: MustMatch('password', 'reenterPassword')}
  )

  get f(){
    return this.forgotForm.controls;
  }
  
    forgotPassword(){
      this.submitted = true;
        if (this.forgotForm.invalid) {
            return;
        }
        this.service.forgotPassword(this.forgotForm.value).subscribe(
          res=>{
            alert("Password Changed")
            this.route.navigate(['/login'])
          },
          err=>{
            console.log(err)
            alert("Sorry try again later")
          }
        )
      
    }
}
