import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService{

  constructor(private orderservice:HttpClient) { }

  baseUrl="http://localhost:8100/api/order"

  getAllOrders():Observable<Array<Order>>{
    return this.orderservice.get<Array<Order>>("http://localhost:8100/api/order");
    
  }
  getOrderById(orderId:number):Observable<Order>{
    return this.orderservice.get<Order>("http://localhost:8100/api/order/"+orderId);
  }
  addOrder(order:Order):Observable<Order>{
    return this.orderservice.post<Order>("http://localhost:8100/api/order",order);
  }
  updateOrder(order:Order){
    return this.orderservice.put(this.baseUrl,order);
  }
  removeOrder(orderId:number){
    return this.orderservice.delete("http://localhost:8100/api/order/"+orderId);
  }
  getOrderByCustomerId(userId:number):Observable<Array<Order>>{
    return this.orderservice.get<Array<Order>>("http://localhost:8100/api/order/customer/"+userId);
  }
}
