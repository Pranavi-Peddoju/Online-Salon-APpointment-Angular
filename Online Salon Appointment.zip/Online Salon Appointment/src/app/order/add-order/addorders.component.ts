import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-listorders',
  templateUrl: './listorders.component.html',
  styleUrls: ['./listorders.component.css']
})
export class AddordersComponent implements OnInit {
  
  constructor(private orderService:OrderService,private builder:FormBuilder) { }

  ngOnInit(): void {
    
  }

}
