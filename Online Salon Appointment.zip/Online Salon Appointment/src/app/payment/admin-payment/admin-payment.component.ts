import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';


@Component({
  selector: 'app-admin-payment',
  templateUrl: './admin-payment.component.html',
  styleUrls: ['./admin-payment.component.css']
})
export class AdminPaymentComponent implements OnInit {
   id:number;
  contactForm:FormGroup;
  payment:Payment
  payments:Array<Payment>=[]
  submitted: boolean = false;
  type:string="gpay";
  status:string="pending";
  cardSelected:boolean;
  closeResult = '';
  constructor(private formbuilder: FormBuilder, private router: Router, private paymentapi:PaymentService,private activatedRoute:ActivatedRoute,private modalService: NgbModal,private fb:FormBuilder) { 
  
  }


  ngOnInit(): void {
    this.paymentapi.getAllPaymentDetails().subscribe(
      (res)=>{
        this.payments=res;
             }
         )
  } 


searchById(){
    console.log(this.id)
    this.paymentapi.getPaymentById(this.id).subscribe(
    res =>{
          this.payment=res;
          this.payments =[];
          this.payments.push(this.payment);
      }
    )
}



deletePayment(id:number){
  console.log(id)
    let result = confirm("Are you sure you wanna delete")
    if(result){
      this.paymentapi.deletePayment(id).subscribe(
        res=>{
          this.paymentapi.getAllPaymentDetails().subscribe(
            (res)=>{
              this.payments=res;
                   }
               )
        }
      )
    }
  }
}

