import { Time } from "@angular/common";

export class Appointment{
    appointmentId:number;
    location:string;
    visitType:string;
    preferredService:string;
    preferredDate:Date;
    preferredTime:Time;
    customer:
    {
        userId:number;
    }
    payment:
    {
        paymentId:number;
    }
}