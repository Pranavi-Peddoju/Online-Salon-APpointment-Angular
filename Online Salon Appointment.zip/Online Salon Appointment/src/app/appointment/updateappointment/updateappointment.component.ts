import { ApplicationModule, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SalonService } from 'src/app/salonservice/salon-service';
import { AppointmentModule } from '../appointment.module';
import { AppointmentService } from '../appointment.service';

@Component({
  selector: 'app-updateappointment',
  templateUrl: './updateappointment.component.html',
  styleUrls: ['./updateappointment.component.css']
})
export class UpdateappointmentComponent implements OnInit {
  appointmentId:number
  appointment:AppointmentModule
  appointments:Array<AppointmentModule>=[];
   date: string;
   salonService:SalonService
  serviceName:string
  appForm:FormGroup

  preferredService:string
userid:number=Number(localStorage.getItem("userId"))
  constructor(private param:ActivatedRoute, private router:Router, private appointmentservice:AppointmentService,private builder:FormBuilder ) { }

  ngOnInit(): void {
    this.param.params.subscribe(
      (param)=>{
        let id=param['id']
        console.log(id);
        this.appointmentservice.getAppointmentById(id).subscribe(
          res=>{
            this.appointment=res
            console.log(this.appointment)
           // alert('Updated Successfully');
           // this.router.navigate(['/customer-appointment/'+id])
          }
        )
      }
    )
   
    this.appForm = this.builder.group(
      {
        preferredService:[this.preferredService],
        location:[''],
        visitType:[''],
        preferredDate:[''],
        preferredTime:[''],
        customer:
        {
          userId:this.userid,
        }
        // ,
        // payment:{
        //   paymentId:['']
        // }
      }
    )
  }
    update()
    {
      this.appointmentservice.updateAppointment(this.appForm.value).subscribe(
        res=>{
          alert('Updated Successfully');
         // this.router.navigate(['/customer-appointment/'+id])
        } 
      )
    }
}
