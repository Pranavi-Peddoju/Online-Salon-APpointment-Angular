import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { SalonService } from '../salon-service';
import { SalonServiceApiService } from '../salon-service-api.service';

@Component({
  selector: 'app-salon-service',
  templateUrl: './salon-service.component.html',
  styleUrls: ['./salon-service.component.css']
})
export class SalonServiceComponent implements OnInit {
  

  salonService:SalonService
  salonservices:Array<SalonService>=[]
  closeResult = '';
  rangevalue = 100;
  price1:string
  price2:string
  userId = Number(localStorage.getItem("userId"))
  constructor(private serviceapi:SalonServiceApiService,private modalService: NgbModal,private param:ActivatedRoute,private router:Router) {  

  }

  ngOnInit(): void {
   
    this.serviceapi.getAllServices().subscribe(
      (res)=>{
        this.salonservices=res;
        console.log(this.salonservices)
      }
    )
    this.param.params.subscribe(
      (param) => {
        let id = param['id']
        this.getById(id)
      }
    )

    this.param.params.subscribe(
      (param) => {
        let name = param['name']
        this.getByName(name)
      }
    )

    this.param.params.subscribe(
      (param) => {
        let duration = param['duration']
        this.getByDuration(duration)
      }
    )

}

  

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  getById(id:number){
    console.log(id)
    this.serviceapi.getServiceById(id).subscribe(
      res=>{
        this.salonService=res;
        this.salonservices = [];
        this.salonservices.push(this.salonService);
      }
    )
  }

  getByName(name:string){
    console.log(name)
    this.serviceapi.getServiceByName(name).subscribe(
      res=>{
        this.salonservices = [];
        this.salonservices=res
      }
    )
  }
  getByDuration(duration:string){
    console.log(duration)
    this.serviceapi.getServiceByDuration(duration).subscribe(
      res=>{
        this.salonservices = [];
        this.salonservices=res
      }
    )
  }
  

  valueChanged(e) {
    this.rangevalue = e.target.value;
  }


  getServicesByPrice(){
   this.router.navigate(['/pricerange'], {
   queryParams: { 'price1': 100, 'price2' : this.rangevalue}
   })
  }

  filter(){
    if(this.rangevalue >100){
      this.getServicesByPrice()
    }
  }

  bookAppointment(id:number){
    console.log(id)
    this.router.navigate(['/book-appointment/'+id])
  }

  

}
