import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-services-admin-dashboard',
  templateUrl: './services-admin-dashboard.component.html',
  styleUrls: ['./services-admin-dashboard.component.css']
})
export class ServicesAdminDashboardComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  showAll(){
    this.route.navigate(['/admin-view-services'])
  }

  deleteService(){
    this.route.navigate(['/delete-service'])
  }

  addService(){
    this.route.navigate(['/addservice'])
  }

}
