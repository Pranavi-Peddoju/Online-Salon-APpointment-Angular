import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicesAdminDashboardComponent } from './services-admin-dashboard.component';

describe('ServicesAdminDashboardComponent', () => {
  let component: ServicesAdminDashboardComponent;
  let fixture: ComponentFixture<ServicesAdminDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServicesAdminDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicesAdminDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
