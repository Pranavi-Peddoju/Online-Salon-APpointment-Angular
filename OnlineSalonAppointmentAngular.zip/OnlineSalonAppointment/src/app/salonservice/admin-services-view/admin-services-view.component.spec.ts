import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminServicesViewComponent } from './admin-services-view.component';

describe('AdminServicesViewComponent', () => {
  let component: AdminServicesViewComponent;
  let fixture: ComponentFixture<AdminServicesViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminServicesViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminServicesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
