import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SalonService } from '../salon-service';
import { SalonServiceApiService } from '../salon-service-api.service';

@Component({
  selector: 'app-update-service',
  templateUrl: './update-service.component.html',
  styleUrls: ['./update-service.component.css']
})
export class UpdateServiceComponent implements OnInit {
    
  salonService:SalonService
  serviceId:number
  showAlert: any;
  color: string;
  message: string;
  constructor(private builder:FormBuilder,private activatedroute:ActivatedRoute, private serviceapi:SalonServiceApiService,private route:Router) { }

  ngOnInit(): void {

    this.activatedroute.params.subscribe(
      (params)=>{
        let id = params['id']
        this.serviceapi.getServiceById(id).subscribe(
          res=>{
            this.salonService = res
            this.serviceForm.setValue(res)
            console.log(this.serviceForm.value)
          }
        )
      }
    )
  }

  serviceForm = this.builder.group({
    serviceId:[''],
    serviceName:['', Validators.required],
    discount:['',Validators.required],
    duration:['',Validators.required],
    price:['',Validators.required]
  })

  get f(){
    return this.serviceForm.controls;
  }

  updateService(){
    this.serviceapi.updateService(this.serviceForm.value).subscribe(
      res=>{
        //alert("updated successfully")
        this.showAlert=true;
        console.log(this.serviceForm.value)
        this.message="Updated Successfully"
        setTimeout(() => {this.route.navigate(['/admin-view-services'])}, 3000);
      },
      err=>{
        this.showAlert=true
        this.color ="red"
        this.message="Sorry Try again in some time."
      }
    )
  }  
}
