import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowBypriceComponent } from './show-byprice.component';

describe('ShowBypriceComponent', () => {
  let component: ShowBypriceComponent;
  let fixture: ComponentFixture<ShowBypriceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowBypriceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowBypriceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
