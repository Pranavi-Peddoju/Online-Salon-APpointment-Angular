import { Injectable } from '@angular/core';
import { HttpClient, HttpParams} from '@angular/common/http'
import { Observable } from 'rxjs';
import { SalonService } from './salon-service';

@Injectable({
  providedIn: 'root'
})
export class SalonServiceApiService {

  salonservice:SalonService

  constructor(private http:HttpClient) { }

  baseUrl="http://localhost:8100/api/salonservice"

  getAllServices():Observable<Array<SalonService>>{
    return this.http.get<Array<SalonService>>(this.baseUrl)
  }

  getServiceById(id:number):Observable<SalonService>{
    return this.http.get<SalonService>("http://localhost:8100/api/salonservice/"+id)
  }

  getServiceByName(name:string):Observable<Array<SalonService>>{
    return this.http.get<Array<SalonService>>("http://localhost:8100/api/salonservice/name/"+name)
  }

  getServiceByDuration(duration:string):Observable<Array<SalonService>>{
    return this.http.get<Array<SalonService>>("http://localhost:8100/api/salonservice/duration/"+duration)
  }

  getServiceByPrice(price1:string, price2:string):Observable<Array<SalonService>>{
    let params = new HttpParams()
                .set("price1", price1)
                .set('price2', price2);
    return this.http.get<Array<SalonService>>("http://localhost:8100/api/salonservice/pricerange",{params})
  }

  deleteServiceById(id:number):Observable<any>{
    return this.http.delete<any>("http://localhost:8100/api/salonservice/"+id)
  }

  addService(salonService:SalonService):Observable<SalonService>{
    return this.http.post<SalonService>(this.baseUrl,salonService)
  }

  updateService(salonService:SalonService):Observable<SalonService>{
    return this.http.put<SalonService>(this.baseUrl,salonService)
  }

}
