import { OriginalPricePipe } from './original-price.pipe';

describe('OriginalPricePipe', () => {
  it('create an instance', () => {
    const pipe = new OriginalPricePipe();
    expect(pipe).toBeTruthy();
  });
});
