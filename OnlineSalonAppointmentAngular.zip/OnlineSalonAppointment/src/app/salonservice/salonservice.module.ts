import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalonServiceComponent } from './salon-service/salon-service.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OriginalPricePipe } from './original-price.pipe';
import {NgbPaginationModule, NgbAlertModule, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { ShowBypriceComponent } from './show-byprice/show-byprice.component';
import { ServicesAdminDashboardComponent } from './services-admin-dashboard/services-admin-dashboard.component';
import { AddServiceComponent } from './add-service/add-service.component';
import { UpdateServiceComponent } from './update-service/update-service.component';
import { AdminServicesViewComponent } from './admin-services-view/admin-services-view.component';

@NgModule({
  declarations: [SalonServiceComponent, OriginalPricePipe, ShowBypriceComponent, ServicesAdminDashboardComponent,AddServiceComponent, UpdateServiceComponent, AdminServicesViewComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    NgbPaginationModule, NgbAlertModule,
    NgbModule
  ]
})
export class SalonserviceModule { }
