import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SalonServiceApiService } from '../salon-service-api.service';

@Component({
  selector: 'app-add-service',
  templateUrl: './add-service.component.html',
  styleUrls: ['./add-service.component.css']
})
export class AddServiceComponent implements OnInit {
  message: string;
  color: string;
  showAlert: boolean;

  constructor(private builder:FormBuilder, private serviceapi:SalonServiceApiService,private route:Router) { }

  ngOnInit(): void {
  }

  serviceForm = this.builder.group({
    serviceName:['', Validators.required],
    discount:['',Validators.required],
    duration:['',Validators.required],
    price:['',Validators.required]
  })

  get f(){
    return this.serviceForm.controls;
  }

  addService(){
    this.serviceapi.addService(this.serviceForm.value).subscribe(
      res=>{
        this.showAlert=true
        this.color ="green"
        this.message="Service details added successfully"
        setTimeout(() => {this.route.navigate(['/admin-view-services'])}, 2000);

      },
      err=>{
        this.showAlert=true
        this.color ="red"
        this.message="Sorry Try again in some time."
      }
    )
  }  
}
