export class SalonService{
    serviceId:number;
    price:number;
    discount:number;
    duration:string;
    serviceName:string
}