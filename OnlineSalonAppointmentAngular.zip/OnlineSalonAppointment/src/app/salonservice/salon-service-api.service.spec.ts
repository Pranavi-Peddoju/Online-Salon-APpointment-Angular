import { TestBed } from '@angular/core/testing';

import { SalonServiceApiService } from './salon-service-api.service';

describe('SalonServiceApiService', () => {
  let service: SalonServiceApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SalonServiceApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
