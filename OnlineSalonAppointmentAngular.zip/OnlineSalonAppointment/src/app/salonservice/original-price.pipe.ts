import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'originalPrice'
})
export class OriginalPricePipe implements PipeTransform {

  transform(value: number, discount:number): unknown {
    let beforeDis = 100 - discount;
    let originalprice = (value * 100) / beforeDis
    return Math.round(originalprice);
  }

}
