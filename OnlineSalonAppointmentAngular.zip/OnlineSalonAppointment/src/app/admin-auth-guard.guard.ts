import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthGuardGuard implements CanActivate {
  constructor(private router: Router){}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
      if(Number(localStorage.getItem("userId"))>999 && Number(localStorage.getItem("userId"))<1999){
        return true;
      }
      this.router.navigate(['login'], { queryParams: { returnUrl: state.url }});
      return false;
  }
  
}
