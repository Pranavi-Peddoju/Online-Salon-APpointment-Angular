import { DatePipe, formatDate } from '@angular/common';
import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SalonService } from 'src/app/salonservice/salon-service';
import { SalonServiceApiService } from 'src/app/salonservice/salon-service-api.service';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  userid:number=Number(localStorage.getItem("userId"));
  //billingDate=new Date().toISOString()
  billingDate = formatDate(new Date() , 'yyyy-MM-dd','en')
  submitted: boolean = false;
serviceid:number 
  orderId:number;
  order:Order;
  orders:Array<Order>=[];
  constructor(private param:ActivatedRoute,private router:Router,private salonService:SalonServiceApiService,private builder:FormBuilder,private orderService:OrderService) { }
  services:SalonService
  amount:number
  orderForm:FormGroup
  ngOnInit(): void {
    this.param.params.subscribe(
      (param) => {​​​​​​​​
        this.serviceid = param['id']
        console.log(this.serviceid)
    this.salonService.getServiceById(this.serviceid).subscribe(
      res=>{​​​​​​​​
        this.services=res;
        console.log(this.services)
        console.log(this.services.price)
        this.amount =this.services.price
        console.log("price asssigned : " + this.amount)
      }​​​​​​​​
    )
    this.orderForm=this.builder.group(
      {
        amount:[this.amount],
        billingDate:[this.billingDate],
        paymentMethod:[''],
        customer:{
        userId:this.userid
          
      }
      }
    )  
  }
  )
 }
  placeOrder(){
    console.log(this.orderForm.value)
    let method:string=this.orderForm.controls['paymentMethod'].value
    console.log(method)
     this.orderService.addOrder(this.orderForm.value).subscribe(
       data=>{
         alert('order placed')
         this.router.navigate(['/payment/'+method])
       }
    )
    //this.router.navigate(['/customer']);
}
}
