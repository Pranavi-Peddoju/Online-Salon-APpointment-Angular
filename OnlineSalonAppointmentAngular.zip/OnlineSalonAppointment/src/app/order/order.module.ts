import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrdersComponent } from './orders/orders.component';
import { AddordersComponent } from './add-order/addorders.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomerordersComponent } from './customerorders/customerorders.component';
import { AdminOrdersComponent } from './admin-orders/admin-orders.component';




@NgModule({
  declarations: [OrdersComponent, AddordersComponent, CustomerordersComponent, AdminOrdersComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports:[
    FormsModule,ReactiveFormsModule
  ]
})
export class OrderModule { }
