import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-customerorders',
  templateUrl: './customerorders.component.html',
  styleUrls: ['./customerorders.component.css']
})
export class CustomerordersComponent implements OnInit {
  orderId:number
  order:Order;
  orders:Array<Order>=[];
  constructor(private activatedRoute:ActivatedRoute ,private orderService:OrderService,private route:Router) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(
      (params)=>{
        let id=params['userId']
        this.orderService.getOrderByCustomerId(id).subscribe(
          (res)=>{
            this.orders=res;
            console.log(this.orders);
          }
        )
      }
    )
     this.activatedRoute.params.subscribe(
       (param)=>{
         let id =param['id']
         console.log(id);
          this.orderService.getOrderById(id).subscribe(
            res=>{
              this.order=res;
              this.orders=[];
              this.orders.push(this.order);
           }
         )
       }
     )
  }
  deleteOrder(orderId:number):void{
    let result = confirm("Are you sure you wanna delete")
    if(result){
      this.orderService.removeOrder(orderId).subscribe(
        res=>{
          this.route.navigate(['/delete-order'])
        }
      )
    }
  }
  addOrder(){
    this.route.navigate(['/add-service-order'])
  }
  searchById(){
    //this.orderId=Number(localStorage.getItem("orderId"))
    console.log(this.orderId);
   this.route.navigate(['/get-order/'+this.orderId]);
  }
  
}
