export class Order{
    orderId:number;
    amount :number;
    billingDate:Date;
    customer:{
        userId:number
    };
    paymentMethod:string;

}