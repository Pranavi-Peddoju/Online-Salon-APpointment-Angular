import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-admin-orders',
  templateUrl: './admin-orders.component.html',
  styleUrls: ['./admin-orders.component.css']
})
export class AdminOrdersComponent implements OnInit {

  orders:Array<Order>=[];
  order:Order;
  searchById:number;
  constructor(private activatedRoute:ActivatedRoute ,private orderService:OrderService,private route:Router) { }

  ngOnInit(): void {
    this.orderService.getAllOrders().subscribe(
      (res)=>{
        this.orders=res;
      }
    )
  }
  search(){
    if(this.searchById>19999){
      this.route.navigate(['/customer-order/'+this.searchById])
    }
    else{
      this.route.navigate(['/get-order/'+this.searchById])
    }
  }
deleteOrder(orderId:number){
 // this.route.navigate(['/delete-order/'+orderId])
 this.orderService.removeOrder(orderId).subscribe(
   res=>{
    this.orderService.getAllOrders().subscribe(
      (res)=>{
        this.orders=res;
      }
    )
   }
 )
}
}
