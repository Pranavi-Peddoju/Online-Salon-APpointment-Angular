import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPaymentComponent } from './add-payment/add-payment.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgbAlertModule, NgbModule, NgbPagination, NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { AdminPaymentComponent } from './admin-payment/admin-payment.component';
import { UpdatePaymentComponent } from './update-payment/update-payment.component';
import { ConfirmPaymentComponent } from './confirm-payment/confirm-payment.component';



@NgModule({
  declarations: [AddPaymentComponent, UpdatePaymentComponent,
  AdminPaymentComponent,
  ConfirmPaymentComponent
  
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgbPaginationModule,
    NgbAlertModule,
    NgbModule,
    
  ]
})
export class PaymentModule { }
