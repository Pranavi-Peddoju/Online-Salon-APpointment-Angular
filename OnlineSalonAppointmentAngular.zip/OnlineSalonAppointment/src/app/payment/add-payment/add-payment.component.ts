import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AppointmentServiceComponent } from 'src/app/appointment/appointment-service/appointment-service.component';
import { AppointmentService } from 'src/app/appointment/appointment.service';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';

@Component({
  selector: 'app-add-payment',
  templateUrl: './add-payment.component.html',
  styleUrls: ['./add-payment.component.css']
})
export class AddPaymentComponent implements OnInit {

  contactForm:FormGroup;
  submitted: boolean = false;
  type:string;
  status:string="pending";
  cardSelected:boolean;
  proceed:boolean=false
  @Input() 
  addForm:FormGroup
  cardId:number;
  cardName:string;
  cardNumber:string;
  cardExpiry:Date;
  cvv:number;
  bankName:string;

payment:Payment

  closeResult = '';
  constructor(private formbuilder: FormBuilder, private router: Router,private appService:AppointmentService, private paymentapi:PaymentService,private activatedRoute:ActivatedRoute,private modalService: NgbModal,private fb:FormBuilder) { 
  
  }
  
  ngOnInit() {
    this.addForm = this.formbuilder.group({
      type: [''],
      status:[this.status],
      card:this.formbuilder.group({
      
        cardName:[''],
        cardNumber:[''],
        cardExpiry:[''],
        cvv:[''],
        bankName:['']
      })
      });
     
  
    this.activatedRoute.params.subscribe(
      (params)=>{
        this.type=params['method']
      }
      
    )
    if(this.type=='Card'){
        this.cardSelected=true;
    }
  
  }


  addPayment(){
    
    console.log(this.addForm.value);
    console.log(this.cardNumber)
    // this.router.navigate(['/confirm-payment']);
      this.proceed=true
  //  this.paymentapi.addPayment(this.addForm.value).subscribe(
  //     res=>{
        alert("Payment still Pending");
        
  //     }    
  //   )
  }
  confirm(){
    this.status="Success"
    this.addForm.controls['status'].setValue(this.status)
    console.log(this.addForm.value);
    this.paymentapi.addPayment(this.addForm.value).subscribe(
      res=>{
        alert("Payment Success");
        this.payment = res
        let id = Number(localStorage.getItem("userId"))
        console.log(this.payment.paymentId)
        
        this.router.navigate(['/customer-order/'+id])
      }
    )
  }

 open(content) {
  this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
}

private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return `with: ${reason}`;
  }
}




}
