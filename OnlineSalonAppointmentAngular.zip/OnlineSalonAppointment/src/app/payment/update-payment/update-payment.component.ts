import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';

@Component({
  selector: 'app-update-payment',
  templateUrl: './update-payment.component.html',
  styleUrls: ['./update-payment.component.css']
})
export class UpdatePaymentComponent implements OnInit {
  obj1:any;
  payment:Payment
  payments:Array<Payment>=[]
  submitted: boolean = false;
  type:string;
  status:string="pending";
  cardSelected:boolean;
  
  closeResult = '';
  constructor(private formbuilder: FormBuilder, private router: Router, private paymentapi:PaymentService,private activatedRoute:ActivatedRoute,private modalService: NgbModal) { 
    this.obj1 = this.paymentapi.updatePayment(this.payment);
  }
  onUpdate(upayment: Payment):any{
    return this.paymentapi.onUpdate(upayment).subscribe(data =>{
      alert(data)
      this.router.navigate(["/"])
    });
  }

  ngOnInit(): void {
  }

}
