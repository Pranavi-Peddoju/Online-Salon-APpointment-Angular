import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Payment } from './payment';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private http: HttpClient) {}
  baseUrl: string = "http://localhost:8100/api/payment"

  getAllPaymentDetails():Observable<Array<Payment>>{
    return this.http.get<Array<Payment>>("http://localhost:8100/api/payment")
  }
  getPaymentById(id:number):Observable<Payment>{
    return this.http.get<Payment>("http://localhost:8100/api/payment/"+id)
  }
  addPayment(payment:Payment):Observable<Payment>{
    return this.http.post<Payment>(this.baseUrl,payment)
  }

  updatePayment(payment:Payment):Observable<Payment>{
    return this.http.put<Payment>(this.baseUrl,Payment)
  }
  deletePayment(id:number):Observable<any>{
    return this.http.delete<any>("http://localhost:8100/api/payment/"+id)
  }
  public onUpdate(updatemp:Payment) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.put("'http://localhost:8100/api/payment/id", updatemp,  { headers, responseType: 'text'});
  }
}
