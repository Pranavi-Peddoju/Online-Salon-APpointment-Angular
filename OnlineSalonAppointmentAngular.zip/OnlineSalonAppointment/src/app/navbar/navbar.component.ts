import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminComponent } from '../customer/admin/admin.component';
import { CustomerComponent } from '../customer/customer/customer.component';
import { LoginComponent } from '../login/login.component';
import { SalonServiceComponent } from '../salonservice/salon-service/salon-service.component';

import { NavbarService } from './navbar.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  search: string
  id: number
  name: string
  links: Array<{ text: string, path: string }>;
  isLoggedIn: boolean
  customer: boolean
  admin: boolean
  role:String
  homePage:boolean
  salon: SalonServiceComponent
  //isServicesClicked = false
  constructor(private router: Router, private navbarService: NavbarService, private builder: FormBuilder, private route: Router) {
    this.router.config.push(
      { path: 'login', component: LoginComponent },
      { path: 'customer', component: CustomerComponent },
      { path: 'admin', component: AdminComponent }
    );
  }

  ngOnInit() {
    this.updateNav();
  }

  home(){
    this.route.navigate(['/'])
    this.homePage = true;
  }

  logout() {
    this.navbarService.updateLoginStatus(false);
    localStorage.removeItem("userId")
    this.router.navigate(['/salon-services']);
      localStorage.setItem("status", "0");
    this.updateNav()
  }

  updateNav() {
    if (localStorage.getItem("status") == "1") {
      this.id = Number(localStorage.getItem("userId"));
      console.log(this.id)
      if (this.id > 9999) {
        this.customer = true
        this.isLoggedIn = true
      } else {
        this.admin = true
        this.isLoggedIn = true
      }
     } else {
      this.isLoggedIn = false
     }
  }

  searchService() {
    var re = new RegExp("[0-9]+");
    if (this.search.match("[0-9]+$")) {
      this.id = Number(this.search)
      this.route.navigate(['salon-service/' + this.id])
    }
    
    else if(this.search.slice(0,1).match("[0-9]+")){
      console.log("duration"+this.search)
      this.route.navigate(['salon-service/duration/' + this.search])
    }else{
    //if (!re.test(this.search)) {
      this.route.navigate(['salon-service/name/' + this.search])
    }

  }

}