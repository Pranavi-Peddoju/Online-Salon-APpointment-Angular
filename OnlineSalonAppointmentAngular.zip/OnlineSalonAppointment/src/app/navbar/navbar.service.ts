import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { LoginComponent } from '../login/login.component';
import { NavbarComponent } from './navbar.component';

@Injectable({
  providedIn: 'root'
})
export class NavbarService {
  search: any
  id: number
  name: string
  customer: boolean
  role:string
  admin: boolean
  private links = new Array<{ text: string, path: string }>();
  private isLoggedIn =  new Subject<boolean>();

  constructor() {
  }
  

  getLoginStatus() {
    return this.isLoggedIn;
  }

  updateLoginStatus(status: boolean) {
    this.isLoggedIn.next(false)
   
  }

  updateNavAfterAuth(){  // role:string){
  //   if(role === 'customer'){
  //     console.log(role)
  //     this.isLoggedIn.next(true)
  //     this.customer =true;
  //   }else{
  //     console.log("admin!23")
  //     this.isLoggedIn.next(true)
  //     this.admin =true;
  //   }
  // }
   // this.nav.updateNav()

  //  if (localStorage.getItem("status") == "1") {
  //   this.id = Number(localStorage.getItem("userId"));
  //   console.log(this.id)
  //   if (this.id > 9999) {
  //     this.customer = true
  //     this.role="customer"
  //     this.isLoggedIn.next(true)
  //   } else {
  //     this.admin = true
  //     this.role="customer"
  //     this.isLoggedIn.next(true)
  //   }
  //  } else {
  //   this.isLoggedIn.next(false)
  //  }


  }

  getRoles(){
    return this.role
  }
}
