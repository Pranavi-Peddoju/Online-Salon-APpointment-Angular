import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginApiService } from '../login-api.service';
import { UserDetails } from '../UserDetails';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  submitted: boolean;
  userDetails:UserDetails
  showAlert: boolean;
  message: string;
  color: string;
  constructor(private builder:FormBuilder, private service:LoginApiService, private route:Router) { }

  ngOnInit(): void {
  }

  changeForm =this.builder.group(
    {
      username:[localStorage.getItem('userId')],
      oldPassword:['',[Validators.required, Validators.minLength(6)]],
      newPassword:['', [Validators.required,Validators.minLength(6)]]
    }
  )

  get f(){
    return this.changeForm.controls;
  }
  
    forgotPassword(){
      this.submitted = true;
        if (this.changeForm.invalid) {
            return;
        }
        console.log(this.changeForm.value)
        this.service.changePassword(this.changeForm.value).subscribe(
          res=>{
            console.log(this.changeForm.value)
            //alert("Password Changed")
            this.showAlert=true
            this.color ="green"
            this.message="Password has been reset successfully"
            if(Number(localStorage.getItem('userId'))>99999){
            setTimeout(() => {this.route.navigate(['/customer'])}, 2000);
            }else{
              setTimeout(() => {this.route.navigate(['/admin'])}, 2000);
            }           
          },
          err=>{
            // alert("Invalid Old Password")
            this.showAlert=true
            this.message="Invalid User Old Password. Enter correct password"
            this.color= "red"
          }
        )

       
      
    }
}
