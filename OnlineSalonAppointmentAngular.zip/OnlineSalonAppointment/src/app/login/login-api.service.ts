import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from './User';
import { UserCredentials } from './UserCredentials';
import { UserForgotPass } from './UserForgotPass';
import { UserDetails } from './UserDetails';

@Injectable({
  providedIn: 'root'
})
export class LoginApiService {

  constructor(private httpclient:HttpClient,private router:Router) { }

  baseUrl="http://localhost:8100/api/user/login";

  public  login(userCredentials:UserCredentials):Observable<User>{
    return this.httpclient.post<User>(this.baseUrl,userCredentials)
  }

  public forgotPassword(userForgotPass:UserForgotPass):Observable<Boolean>{
    return this.httpclient.post<Boolean>("http://localhost:8100/api/user/forgotpassword",userForgotPass)
  }

  public changePassword(userDetails:UserDetails):Observable<Boolean>{
    return this.httpclient.post<Boolean>("http://localhost:8100/api/user/changepassword",userDetails)
  }
}
