export class UserForgotPass{
    username:string
    password:string
    reenterPassword:string
}