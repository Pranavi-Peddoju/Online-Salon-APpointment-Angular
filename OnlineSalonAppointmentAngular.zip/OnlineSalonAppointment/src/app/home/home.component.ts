import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminComponent } from '../customer/admin/admin.component';
import { CustomerComponent } from '../customer/customer/customer.component';
import { LoginComponent } from '../login/login.component';
import { NavbarService } from '../navbar/navbar.service';
import { SalonServiceComponent } from '../salonservice/salon-service/salon-service.component';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  images = [1044, 1011, 984].map((n) => ``);
  search: any
  id: number
  name: string
  links: Array<{ text: string, path: string }>;
  isLoggedIn: boolean
  customer: boolean
  admin: boolean
  role:String
  salon: SalonServiceComponent
  //isServicesClicked = false
  constructor(private router: Router, private builder: FormBuilder, private route: Router, private nav:NavbarService) {
    
  }

  ngOnInit() {
    
  }
  

}
