import { ApplicationModule, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SalonService } from 'src/app/salonservice/salon-service';
import { AppointmentModule } from '../appointment.module';
import { AppointmentService } from '../appointment.service';

@Component({
  selector: 'app-updateappointment',
  templateUrl: './updateappointment.component.html',
  styleUrls: ['./updateappointment.component.css']
})
export class UpdateappointmentComponent implements OnInit {
  appointmentId:number
  appointment:AppointmentModule
  appointments:Array<AppointmentModule>=[];
   date: string;
   salonService:SalonService
  serviceName:string
  appForm:FormGroup

  preferredService:string
userid:number=Number(localStorage.getItem("userId"))
  constructor(private param:ActivatedRoute, private router:Router, private appointmentservice:AppointmentService,private builder:FormBuilder ) { }

  ngOnInit(): void {
    this.param.params.subscribe(
      (param)=>{
        let id=param['id']
        console.log(id);
        this.appointmentservice.getAppointmentById(id).subscribe(
          res=>{
            this.appointment=res
            console.log(this.appointment)
            this.appForm.setValue(this.appointment)
           // alert('Updated Successfully');
           // this.router.navigate(['/customer-appointment/'+id])
          }
        )
      }
    )
   
    this.appForm = this.builder.group(
      {
        appointmentId:[''],
        preferredService:[this.preferredService],
        location:[''],
        visitType:[''],
        preferredDate:[''],
        preferredTime:[''],
        customer:
        {
          userId:this.userid,
        }
        ,
        payment:{
          paymentId:[99]
        }
      }
    )
  }
    updateAppointment()
    {
      
      //this.appForm.controls['payment'].get('paymentId').setValue("629919")
      this.appointmentservice.updateAppointment(this.appForm.value).subscribe(
        res=>{
          alert('Updated Successfully');
          console.log(this.appForm.value)
         this.router.navigate(['/customer-appointment/'+this.userid])
        } 
      )
    }
}
