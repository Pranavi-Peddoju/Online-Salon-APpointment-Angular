import { HttpClient } from '@angular/common/http';
import { ApplicationModule, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppointmentModule } from './appointment.module';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  constructor(private appointmentservice:HttpClient) { }
 
  baseUrl="http://localhost:8100/api/appointment"
  
  getAllAppointments():Observable<Array<AppointmentModule>>{
    return this.appointmentservice.get<Array<AppointmentModule>>("http://localhost:8100/api/appointment");
    
  }
  getAppointmentById(appointmentId:number):Observable<AppointmentModule>{
    return this.appointmentservice.get<AppointmentModule>("http://localhost:8100/api/appointment/"+appointmentId);
  }
  addAppointment(appointment:AppointmentModule){
    return this.appointmentservice.post(this.baseUrl,appointment);
  }
  updateAppointment(appointment:AppointmentModule){
    return this.appointmentservice.put(this.baseUrl,appointment);
  }
  removeAppointment(appointmentId:number){
    return this.appointmentservice.delete("http://localhost:8100/api/appointment/"+appointmentId);
  }
  getAppointmentByCustomerId(userId:number):Observable<Array<AppointmentModule>>{
    return this.appointmentservice.get<Array<AppointmentModule>>("http://localhost:8100/api/appointment/customer/"+userId);
  }
}
