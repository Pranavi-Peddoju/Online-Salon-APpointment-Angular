import { ApplicationModule, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentModule } from '../appointment.module';
import { AppointmentService } from '../appointment.service';

@Component({
  selector: 'app-admin-appointment',
  templateUrl: './admin-appointment.component.html',
  styleUrls: ['./admin-appointment.component.css']
})
export class AdminAppointmentComponent implements OnInit {
  searchById:number
  appointments:Array<AppointmentModule>=[]
  appointment:AppointmentModule
 

  constructor(private route:Router,private appointmentService:AppointmentService) { }

  ngOnInit(): void {
    this.appointmentService.getAllAppointments().subscribe(
      (res)=>{
        this.appointments=res;
      }
    )
  }
  search(){
    if(this.searchById>99999){
      this.route.navigate(['/get-appointment/'+this.searchById])
    }
    // else{
    //   this.route.navigate(['/get-appointment/'+this.searchById])
    // }
  }
deleteOrder(appointmentId:number){
  this.route.navigate(['/delete-appointment/'+appointmentId])
}
addAppointment()
{

}
}
