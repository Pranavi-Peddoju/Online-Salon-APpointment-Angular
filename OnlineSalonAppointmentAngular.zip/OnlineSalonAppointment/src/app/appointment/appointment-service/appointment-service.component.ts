
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SalonService } from 'src/app/salonservice/salon-service';
import { SalonServiceApiService } from 'src/app/salonservice/salon-service-api.service';
import { AppointmentModule } from '../appointment.module';
import { AppointmentService } from '../appointment.service';

@Component({
  selector: 'app-appointment-service',
  templateUrl: './appointment-service.component.html',
  styleUrls: ['./appointment-service.component.css']
})
export class AppointmentServiceComponent implements OnInit {
  salonService:SalonService
  serviceName:string
  home:boolean=true
  visitType:string
  appForm:FormGroup
  appointment:AppointmentModule
  appointments:Array<AppointmentModule>=[]
  //preferredDate=Date.now().toLocaleString
  userid:number=Number(localStorage.getItem("userId"))
  serviceid:number
  date: string;
  preferredService:string
  constructor(private serviceapi:SalonServiceApiService, private param:ActivatedRoute,private router:Router, private builder:FormBuilder,private appointmentservice:AppointmentService) {
   // this.id=Number(localStorage.getItem("userId"))
   }
 
  ngOnInit(): void {
    //this.date = this.datePipe.transform(new Date(), 'yyyy-mm-dd');
    this.param.params.subscribe(
      (param) => {
         this.serviceid = param['id']
        console.log(this.serviceid)
    this.serviceapi.getServiceById(this.serviceid).subscribe(
      res=>{
        this.salonService=res;
        console.log(this.salonService)
        console.log(this.salonService.serviceName)
        this.preferredService =this.salonService.serviceName
        console.log("name asssigned : " + this.preferredService)
      }
    )
      }
    )

   
 
    this.appForm = this.builder.group(
      {
        preferredService:[this.preferredService],
        location:[''],
        visitType:[''],
        preferredDate:[''],
        preferredTime:[''],
        customer:
        {
          userId:this.userid,
        }
      }
    )

    if(this.appForm.controls['visitType'].value=="Home"){
      this.home=true;
    }
  }
 
  order()
  {
    console.log(this.appForm.value)
    this.router.navigate(['/place-order/'+this.serviceid])
  }
  bookAppointment(){
    console.log(this.appForm.value)
     this.appointmentservice.addAppointment(this.appForm.value).subscribe(
       data=>{
        this.router.navigate(['/place-order/'+this.serviceid])
       }
    )
    
}
}