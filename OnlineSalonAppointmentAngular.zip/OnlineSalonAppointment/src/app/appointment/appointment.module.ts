import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppointmentServiceComponent } from './appointment-service/appointment-service.component';
import { CustomerAppointmentComponent } from './customer-appointment/customer-appointment.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpdateappointmentComponent } from './updateappointment/updateappointment.component';
import { AdminAppointmentComponent } from './admin-appointment/admin-appointment.component';



@NgModule({
  declarations: [AppointmentServiceComponent, CustomerAppointmentComponent, UpdateappointmentComponent, AdminAppointmentComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class AppointmentModule { }
