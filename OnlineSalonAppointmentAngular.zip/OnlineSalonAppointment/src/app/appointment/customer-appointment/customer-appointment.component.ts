import { DatePipe } from '@angular/common';
import { ApplicationModule, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppointmentModule } from '../appointment.module';
import { AppointmentService } from '../appointment.service';

@Component({
  selector: 'app-customer-appointment',
  templateUrl: './customer-appointment.component.html',
  styleUrls: ['./customer-appointment.component.css']
})
export class CustomerAppointmentComponent implements OnInit {
 appointmentId:number
 appointment:ApplicationModule
 appointments:Array<AppointmentModule>=[];
  date: string;
  constructor(private activatedRoute:ActivatedRoute,private route:Router,private appointmentService:AppointmentService) { }

  ngOnInit(): void
   {
   
    this.activatedRoute.params.subscribe(
      (params)=>
      {
         
        let id=params['id']
        console.log("appointment"+id)
        this.appointmentService.getAppointmentByCustomerId(id).subscribe(
          (res)=>{
            this.appointments=res;
            console.log(this.appointments);
          }
        )
       }
    )
    this.activatedRoute.params.subscribe(
      (param)=>{
        let id =param['id']
        console.log(id);
         this.appointmentService.getAppointmentById(id).subscribe(
           res=>{
             this.appointment=res;
             this.appointments=[];
             this.appointments.push(this.appointment);
          }
        )
      }
    )
 
  }
  addAppointment(){
    this.route.navigate(['/add-appointment'])
  }
  deleteAppointment(appointmentId:number):void{
    let result = confirm("Are you sure you wanna delete")
    if(result){
      this.appointmentService.removeAppointment(appointmentId).subscribe(
        res=>{
          this.route.navigate(['/delete-appointment'])
        }
      )
    }
  }
  updateAppointment(appointmentId:number)
  {
    
        this.route.navigate(['/update-appointment/'+appointmentId])
      
    
  }
  searchById(){
    
    console.log(this.appointmentId);
   this.route.navigate(['/get-appointment/'+this.appointmentId]);
  }
}
