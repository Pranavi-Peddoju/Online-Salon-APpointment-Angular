import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Admin } from './Admin';

@Injectable({
  providedIn: 'root'
})
export class AdminApiService {

  
  constructor(private httpclient:HttpClient,private router:Router) { }

  baseUrl="http://localhost:8100/api/admin";

  public register(admin:Admin):Observable<Admin>{
    return this.httpclient.post<Admin>(this.baseUrl,admin)
  }

}
