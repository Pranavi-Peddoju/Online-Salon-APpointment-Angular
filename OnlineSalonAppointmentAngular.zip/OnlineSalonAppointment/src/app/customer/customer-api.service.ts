import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Customer } from './Customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerApiService {

  
  constructor(private httpclient:HttpClient,private router:Router) { }

  baseUrl="http://localhost:8100/api/customer/register";

  public register(customer:Customer):Observable<Customer>{
    return this.httpclient.post<Customer>(this.baseUrl,customer)
  }

  public update(customer:Customer):Observable<Customer>{
    return this.httpclient.put<Customer>("http://localhost:8100/api/customer",customer)
  }

  public getById(id:number):Observable<Customer>{
    return this.httpclient.get<Customer>("http://localhost:8100/api/customer/"+id)
  }

  public confirmRegister(otp:number):Observable<Customer>{
    // let params = new HttpParams()
    //                 .set("otp",otp)
    return this.httpclient.post<Customer>("http://localhost:8100/api/customer/confirm",otp)
  }

}