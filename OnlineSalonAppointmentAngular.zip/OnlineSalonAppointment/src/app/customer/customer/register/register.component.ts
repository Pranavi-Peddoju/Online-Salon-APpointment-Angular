import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginApiService } from 'src/app/login/login-api.service';
import { User } from 'src/app/login/User';
import { UserCredentials } from 'src/app/login/UserCredentials';
import { NavbarService } from 'src/app/navbar/navbar.service';
import { CustomerApiService } from '../../customer-api.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  
  isLoggedIn = false;
  role = '';
  showAlert:boolean
  user:User;
  userCredential:UserCredentials
  submitted = false;

  constructor(private builder:FormBuilder,private navbarService: NavbarService,private route:Router, private service:CustomerApiService) { 
    this.navbarService.getLoginStatus().subscribe(status => this.isLoggedIn = status);
  }

  ngOnInit(): void {
  }

  registerForm = this.builder.group(
    {
      userName:['',Validators.required],
      password:['',[Validators.required, Validators.minLength(6)]],
      name:['',Validators.required],
      email:['',Validators.required],
      contactNo:['',[Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern("[0-9]+")]],
      dob:['',Validators.required]
  })

  get f() { return this.registerForm.controls; }

  registerUser() {

    console.log(this.registerForm.value)
    this.service.register(this.registerForm.value).subscribe(
      res=>{
        this.route.navigate(['/login'])
      },
      err=>{
        alert("UserName is already take please choose another user Name")
      }
    )

   }
}
