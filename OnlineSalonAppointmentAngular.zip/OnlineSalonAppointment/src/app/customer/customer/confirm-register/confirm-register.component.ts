import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginApiService } from 'src/app/login/login-api.service';
import { User } from 'src/app/login/User';
import { UserCredentials } from 'src/app/login/UserCredentials';
import { NavbarService } from 'src/app/navbar/navbar.service';
import { CustomerApiService } from '../../customer-api.service';

@Component({
  selector: 'app-confirm-register',
  templateUrl: './confirm-register.component.html',
  styleUrls: ['./confirm-register.component.css']
})
export class ConfirmRegisterComponent implements OnInit {

 
  isLoggedIn = false;
  role = '';
  showAlert:boolean
  user:User;
  userCredential:UserCredentials
  submitted = false;
  otp:string
  otpNo:number

  constructor(private builder:FormBuilder,private navbarService: NavbarService,private activatedroute:ActivatedRoute ,private route:Router, private service:CustomerApiService) { 
    this.navbarService.getLoginStatus().subscribe(status => this.isLoggedIn = status);
  }

  ngOnInit(): void {

    // this.activatedroute.queryParams.subscribe(
    //   data =>{
    //     console.log(data)
    //     this.otp=data.otp
    //     //console.log(this.otp)
    //     this.service.confirmRegister(this.otp).subscribe(
    //       res=>{
    //         this.route.navigate(['/login'])
    //       }
    //     )
    //   }
    // )
  }

  loginForm = this.builder.group(
    {
      otp:['']
  })

  get f() { return this.loginForm.controls; }

  loginUser() {
    this.otpNo = this.loginForm.controls['otp'].value
    // this.route.navigate(['/confirm-registration'],{
    //   queryParams: { 'otp': this.otpNo}
    // })
    console.log(this.loginForm.value)
    this.confirmRegistration()
  }

  confirmRegistration(){
    this.service.confirmRegister(this.loginForm.value).subscribe(
      res=>{
        this.route.navigate(['/login'])
      }
    )
  }


}
