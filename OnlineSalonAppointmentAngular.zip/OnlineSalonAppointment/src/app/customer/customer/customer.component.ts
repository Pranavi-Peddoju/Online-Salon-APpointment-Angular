import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  userId:number;
  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  changePassword(){
    this.route.navigate(['/change-password'])
  }

  updateAddress(){
    this.route.navigate(['/address'])
  }

  myOrders(){
    this.userId=Number(localStorage.getItem("userId"))
    this.route.navigate(['/customer-order/'+this.userId])
    
  }
  myAppointment()
 {
  this.userId=Number(localStorage.getItem("userId"))
  console.log(this.userId)
  this.route.navigate(['/customer-appointment/'+this.userId])
 }


}
