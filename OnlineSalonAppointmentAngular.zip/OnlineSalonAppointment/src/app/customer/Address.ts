export class Address{
    doorNo:string
    street:string
    state:string
    city:string
    pinCode:String
}