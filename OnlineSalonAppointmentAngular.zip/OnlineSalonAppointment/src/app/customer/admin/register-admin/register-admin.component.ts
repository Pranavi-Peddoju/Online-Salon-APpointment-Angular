import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/login/User';
import { UserCredentials } from 'src/app/login/UserCredentials';
import { AdminApiService } from '../../admin-api.service';
import { CustomerApiService } from '../../customer-api.service';

@Component({
  selector: 'app-register-admin',
  templateUrl: './register-admin.component.html',
  styleUrls: ['./register-admin.component.css']
})
export class RegisterAdminComponent implements OnInit {
 
  isLoggedIn = false;
  role = '';
  showAlert:boolean
  user:User;
  userCredential:UserCredentials
  submitted = false;
  color: string;
  message: string;

  constructor(private builder:FormBuilder,private route:Router, private service:AdminApiService) { 
  }

  ngOnInit(): void {
  }

  registerForm = this.builder.group(
    {
      userName:['',Validators.required],
      password:['',[Validators.required, Validators.minLength(6)]],
      emailId:['',Validators.required],
      contactNo:['',[Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern("[0-9]+")]]
      
  })

  get f() { return this.registerForm.controls; }

  registerUser() {

    console.log(this.registerForm.value)
    this.service.register(this.registerForm.value).subscribe(
      res=>{
        this.showAlert=true
            this.color ="green"
            this.message="Admin details registered successfully"
        setTimeout(() => {this.route.navigate(['/admin'])}, 2000);

      },
      err=>{
        this.showAlert=true
        this.color ="red"
        this.message="UserName is already taken please choose another user Name"
        //alert("UserName is already taken please choose another user Name")
      }
    )

   }
}
