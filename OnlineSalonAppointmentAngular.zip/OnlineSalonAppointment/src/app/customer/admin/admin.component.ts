import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  openServiceDashboard(){
    this.route.navigate(['/services-dashboard'])
  }

  adminDetailsDashboard(){
    this.route.navigate(['/admin-details-dashboard'])
  }

  adminOrders()
  {
    this.route.navigate(['/admin-orders'])
  }

  openAppointmentDashboard()
  {
    this.route.navigate(['/appointment-dashboard'])
  }

  paymentDashboard(){
    console.log('all details');
    this.route.navigate(['/admin-payment-view'])
  }

}
