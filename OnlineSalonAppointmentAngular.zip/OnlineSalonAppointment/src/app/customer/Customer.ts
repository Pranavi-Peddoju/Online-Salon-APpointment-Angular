import { Address } from "./Address"
export class Customer{
    userName:string
    password:string
    name:string
    contactNo:number
    email:string
    dob:Date
    address:Address
}