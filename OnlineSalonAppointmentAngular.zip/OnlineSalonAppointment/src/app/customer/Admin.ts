export class Admin{
    userName:string
    password:string
    contactNo:number
    email:string
}